import React from 'react';
import Navbarr from './Navbarr';

const SelfCareTips = () => {
  const styles = {
    container: {
      padding: '20px',
      fontFamily: 'Arial, sans-serif',
      backgroundColor: '#f9f9f9',
      color: '#333',
      maxWidth: '800px',
      margin: '0 auto',
      lineHeight: '1.6',
    },
    header: {
      textAlign: 'center',
      marginBottom: '40px',
    },
    heading: {
      color: '#00796b',
    },
    subheading: {
      fontSize: '2em',
      borderBottom: '2px solid #e0e0e0',
      paddingBottom: '10px',
      marginBottom: '20px',
      color: '#00796b',
    },
    paragraph: {
      fontSize: '1em',
      lineHeight: '1.6',
    },
    image: {
      width: '300px',
      height: '200px',
      marginTop: '20px',
    },
    list: {
      listStyleType: 'disc',
      marginLeft: '20px',
    },
    footer: {
      textAlign: 'center',
      fontSize: '0.9em',
      color: '#555',
      marginTop: '40px',
    },
  };

  return (
    <div style={styles.container}>
      <Navbarr />
      <br></br>
      <header style={styles.header}>
        <h1 style={styles.heading}>Self Care Tips</h1>
        <img
          src='https://cdn.psychologytoday.com/sites/default/files/styles/article-inline-half-caption/public/field_blog_entry_images/2018-12/take-care-of-yourself.jpg?itok=G62EoHsh'
          style={styles.image}
          alt="self"
        />
      </header>
    
      <section>
        <h2 style={styles.subheading}>External Physical Cleanliness: Caring for Our Body and Environment</h2>
        <p style={styles.paragraph}>
          External physical cleanliness encompasses the hygiene and upkeep of our body, clothing, and surroundings. Taking care of our physical well-being is not only a matter of personal pride but also reflects our respect for ourselves and those around us.
        </p>
        <p style={styles.paragraph}>
          Body cleanliness begins with regular bathing and using appropriate products like cotton swabs and optionally lotions, oils, and other. The act of bathing not only cleanses the body but also refreshes the mind, promoting a sense of rejuvenation and readiness to face the day ahead.
        </p>
        <p style={styles.paragraph}>
          Keeping our environment clean, including our homes, is equally important. A neat and organized living space fosters a sense of peace and tranquility, reducing stress and promoting a harmonious living environment.
        </p>
      </section>
    
      <section>
        <h2 style={styles.subheading}>Internal Physical Cleanliness</h2>
        <p style={styles.paragraph}>
          Additionally, it is crucial to be mindful of what we allow into our bodies through our diet. A balanced and nutritious diet, preferably lacto-vegetarian as recommended by yogis, nourishes both the body and mind. Avoiding intoxicating substances, tobacco, and vaping is essential to safeguard our physical and mental health.
        </p>
      </section>
    
      <section>
        <h2 style={styles.subheading}>Mental Cleanliness: Nurturing the Body-Mind Connection</h2>
        <p style={styles.paragraph}>
          Mental cleanliness can also be divided into two. External mental cleanliness and internal mental cleanliness.
        </p>
        
        <h3 style={styles.subheading}>Internal Mental Cleanliness</h3>
        <p style={styles.paragraph}>
          The content we consume, such as the music we listen to, the books we read, and the movies we watch, has a profound impact on our mental state. Being selective about the information and media we expose ourselves to helps maintain a positive and healthy mindset. It involves being conscious of what we allow into our minds through our senses, such as what we see, hear, touch, smell, and taste.
        </p>
        
        <h3 style={styles.subheading}>External Mental Cleanliness</h3>
        <p style={styles.paragraph}>
          It delves deeper into the realm of our thoughts, emotions, and the influences that shape our minds. The most challenging aspect of internal mental cleanliness lies in managing our own thoughts and emotions. It is natural for envy, jealousy, and negative emotions to arise at times, but it is essential to address them constructively. Recognizing harmful thoughts and applying counter-thoughts that promote positivity and understanding can help purify our minds from negativity.
        </p>
        <p style={styles.paragraph}>
          Mental cleanliness also involves cultivating mindfulness and self-awareness. Engaging in practices like meditation and introspection allows us to delve into the depths of our minds, understanding our emotions, and fostering inner peace and emotional resilience.
        </p>
      </section>
    
      <footer style={styles.footer}>
        <p>Conclusion: The importance of physical and mental cleanliness cannot be overstated. It is a holistic approach that encompasses the care of our body, mind, and environment. Nurturing our physical health ensures that we have the energy and vitality to lead fulfilling lives, while mental cleanliness empowers us to navigate challenges with clarity and emotional resilience.</p>
        <p>The practice of Shaoca, as advocated by yogis, encourages us to be conscious of what we consume, both externally and internally. By choosing what nourishes our body and mind positively, we create a harmonious and balanced existence.</p>
        <p>As we embark on the journey of self-development and inner growth, let us embrace the significance of physical and mental cleanliness. By taking care of ourselves holistically, we lay the foundation for a happier, healthier, and more harmonious life. It is a journey worth undertaking—one that leads to greater self-discovery, inner peace, and the realization of our highest potential.</p>
      </footer>
    </div>
  );
};

export default SelfCareTips;
