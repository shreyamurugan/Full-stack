import React from 'react';
import { Carousel } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbarr from './Navbarr';

const About = () => {
  const styles = {
    container: {
      maxWidth: '800px',
      margin: '0 auto',
      padding: '50px',
      backgroundColor: '#ffffff',
      fontFamily: 'Arial, sans-serif',
      borderRadius: '10px',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
      animation: 'slideIn 1.5s ease-out',
      color: '#333',
    },
    header: {
      textAlign: 'center',
      marginBottom: '40px',
      animation: 'fadeInDown 2s',
    },
    headerText: {
      fontSize: '1.2em',
      color: '#007bff',
      animation: 'fadeInUp 2s',
    },
    carouselImage: {
      height: '400px',
      objectFit: 'cover',
      borderRadius: '10px',
      animation: 'zoomIn 1.5s',
    },
    section: {
      marginBottom: '40px',
      animation: 'fadeIn 2s',
      padding: '20px',
      backgroundColor: '#f0f8ff',
      borderRadius: '10px',
      transition: 'background-color 0.3s',
    },
    sectionHeading: {
      animation: 'fadeInLeft 2s',
      fontSize: '1.8em',
      color: '#007bff',
      marginBottom: '20px',
      textTransform: 'uppercase',
      letterSpacing: '1.5px',
    },
    sectionText: {
      animation: 'fadeInRight 2s',
      lineHeight: '1.6',
      color: '#555',
      transition: 'color 0.3s',
    },
    ul: {
      paddingLeft: '20px',
    },
    button: {
      margin: '10px',
      padding: '10px 20px',
      backgroundColor: '#007bff',
      color: '#fff',
      border: 'none',
      borderRadius: '5px',
      transition: 'transform 0.2s, background-color 0.2s',
      animation: 'bounceIn 1s',
      cursor: 'pointer',
    },
    buttonHover: {
      transform: 'scale(1.1)',
      backgroundColor: '#0056b3',
    },
    sectionHover: {
      backgroundColor: '#e6f7ff',
    },
    sectionTextHover: {
      color: '#333',
    },
    keyframes: `
      @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }
      @keyframes fadeInDown {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
      }
      @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
      }
      @keyframes fadeInLeft {
        from { opacity: 0; transform: translateX(-20px); }
        to { opacity: 1; transform: translateX(0); }
      }
      @keyframes fadeInRight {
        from { opacity: 0; transform: translateX(20px); }
        to { opacity: 1; transform: translateX(0); }
      }
      @keyframes slideIn {
        from { transform: translateX(-100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
      @keyframes zoomIn {
        from { transform: scale(0.8); opacity: 0; }
        to { transform: scale(1); opacity: 1; }
      }
      @keyframes bounceIn {
        from { transform: scale(0.5); opacity: 0; }
        50% { transform: scale(1.2); opacity: 1; }
        to { transform: scale(1); opacity: 1; }
      }
    `,
  };

  return (
    <div style={styles.container}>
      <Navbarr/><br></br>
      <style>{styles.keyframes}</style>
      <header style={styles.header}>
        <h1 style={{ color: '#333' }}>About Mental Health & Wellness</h1>
        <p style={styles.headerText}>Making the World a Better Place For All of Us</p>
        <a
          href="/donate"
          className="btn"
          style={styles.button}
          onMouseEnter={(e) => e.target.style.transform = 'scale(1.1)'}
          onMouseLeave={(e) => e.target.style.transform = 'scale(1)'}
        >
          Make a Donation
        </a>
        <a
          href="/contact"
          className="btn"
          style={styles.button}
          onMouseEnter={(e) => e.target.style.transform = 'scale(1.1)'}
          onMouseLeave={(e) => e.target.style.transform = 'scale(1)'}
        >
          Contact Us
        </a>
      </header>

      <Carousel className="about-carousel">
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://i0.wp.com/mindblossom.org/wp-content/uploads/2023/03/pexels-ingo-joseph-609771.jpg?w=1080&ssl=1"
            alt="First slide"
            style={styles.carouselImage}
          />
          <Carousel.Caption>
            <h3>Our Story</h3>
            <p>Founded in 2023, inspired by personal experiences.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://mfgc.in/wp-content/uploads/2020/08/Youth-Ministry-V2.jpg"
            alt="Second slide"
            style={styles.carouselImage}
          />
          <Carousel.Caption>
            <h3>Our Mission</h3>
            <p>Striving to prevent and combat mental illness.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://mfgc.in/wp-content/uploads/2020/08/Youth-Ministry-V2.jpg"
            alt="Third slide"
            style={styles.carouselImage}
          />
          <Carousel.Caption>
            <h3>Our Vision</h3>
            <p>Creating a supportive community for mental health.</p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>

      <section
        style={styles.section}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = styles.sectionHover.backgroundColor;
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = styles.section.backgroundColor;
        }}
      >
        <h2 style={styles.sectionHeading}>Our Story</h2>
        <p
          style={styles.sectionText}
          onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
          onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
        >
          Mindful Oasis was founded in 2023 by Pernille (Bülow) Yilmam, whose personal experiences inspired its establishment.
          You can read more about Pernille’s background on her website.
        </p>
        <p
          style={styles.sectionText}
          onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
          onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
        >
          But Mindful Oasis is not the story of a single person. Mindful Oasis is ultimately the result of long conversations
          among people who are passionate about preventing and combating mental illness. In 2023, those conversations turned
          into action.
        </p>
        <p
          style={styles.sectionText}
          onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
          onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
        >
          Join us in creating a better place for all of us.
        </p>
      </section>

      <section
        style={styles.section}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = styles.sectionHover.backgroundColor;
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = styles.section.backgroundColor;
        }}
      >
        <h2 style={styles.sectionHeading}>Our Mission</h2>
        <p
          style={styles.sectionText}
          onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
          onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
        >
          Mindful Oasis strives to prevent and combat mental illness through mental health education and fostering community support.
        </p>
        <p
          style={styles.sectionText}
          onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
          onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
        >
          We integrate humanity with science by using mental health education, an evidence-based method, to empower people’s understanding
          of their own and others’ physical and mental wellbeing. Through lectures, discussions, and practice people build up a repertoire
          of positive coping mechanisms, rendering them better at dealing with current stressors and more resilient to future ones.
        </p>
        <p
          style={styles.sectionText}
          onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
          onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
        >
          Our goal is threefold:
        </p>
        <ul style={styles.ul}>
          <li
            style={styles.sectionText}
            onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
            onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
          >
            To build people’s evidence-based knowledge foundation on mental health and illness
          </li>
          <li
            style={styles.sectionText}
            onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
            onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
          >
            To empower people with effective communication skills to talk about mental illness with various stakeholders, including healthcare providers, peers, employers, and loved ones
          </li>
          <li
            style={styles.sectionText}
            onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
            onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
          >
            To ensure they have the skills to seek out and implement effective mental health support for themselves and others
          </li>
        </ul>
        <p
          style={styles.sectionText}
          onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
          onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
        >
          Through this process, we build community among peers and ensure sustainable and long-lasting effects of our programs.
        </p>
        <p
          style={styles.sectionText}
          onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
          onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
        >
          Mindful Oasis is dedicated to thinking outside the box and incorporating scientifically validated methods and technology to support continued mental health education and fostering continued community support.
        </p>
      </section>

      <section
        style={styles.section}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = styles.sectionHover.backgroundColor;
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = styles.section.backgroundColor;
        }}
      >
        <h2 style={styles.sectionHeading}>Our Vision</h2>
        <p
          style={styles.sectionText}
          onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
          onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
        >
          Mindful Oasis envisions a world where mental health education is integrated into all community centers, schools, and companies with the aim to prevent and reduce mental illness. This vision is two fold:
        </p>
        <ul style={styles.ul}>
          <li
            style={styles.sectionText}
            onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
            onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
          >
            Mindful Oasis envisions a world where an individual has the general knowledge to understand their feelings, thoughts, and sensations from a personal and scientific perspective.
          </li>
          <li
            style={styles.sectionText}
            onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
            onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
          >
            We envision a world where the community (friends, family, community centers) can serve as reliable support for individuals struggling with mental illness.
          </li>
        </ul>
        <p
          style={styles.sectionText}
          onMouseEnter={(e) => e.currentTarget.style.color = styles.sectionTextHover.color}
          onMouseLeave={(e) => e.currentTarget.style.color = styles.sectionText.color}
        >
          Mindful Oasis envisions this world to rely on evidence-based methods, including technology, education, and group activities, to continuously support individuals and communities thrive.
        </p>
      </section>
    </div>
  );
};

export default About;
