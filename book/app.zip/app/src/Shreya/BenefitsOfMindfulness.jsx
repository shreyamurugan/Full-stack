import React from 'react';
import Navbarr from './Navbarr';

const BenefitsOfMindfulness = () => {
  const styles = {
    content: {
      padding: '2rem',
      backgroundColor: '#f9f9f9',
      fontFamily: 'Arial, sans-serif',
      color: '#333',
      maxWidth: '800px',
      margin: '0 auto',
      lineHeight: '1.6',
    },
    header: {
      textAlign: 'center',
      marginBottom: '40px',
    },
    heading: {
      fontSize: '2em',
      color: '#00796b',
    },
    subheading: {
      fontSize: '1.5em',
      color: '#00796b',
      marginTop: '20px',
    },
    paragraph: {
      marginBottom: '1rem',
    },
    image: {
      width: '300px',
      height: '200px',
      margin: '1rem 0',
    },
    list: {
      listStyleType: 'disc',
      marginLeft: '20px',
    },
    listItem: {
      marginBottom: '0.5rem',
    },
    footer: {
      textAlign: 'center',
      fontSize: '0.9em',
      color: '#555',
      marginTop: '40px',
    },
  };

  return (
    <div style={styles.content}>
      <Navbarr /><br></br>
      <header style={styles.header}>
        <h1 style={styles.heading}>Benefits of Mindfulness</h1>
        <p style={styles.paragraph}>
          Mindfulness can help reduce stress, improve your mental and physical health, and even increase your overall happiness in life. These mindfulness techniques can help you start reaping the benefits.
        </p>
        <img
          src="https://www.helpguide.org/wp-content/uploads/2023/02/Benefits-of-Mindfulness.jpeg"
          style={styles.image}
          alt="Benefits of Mindfulness"
        />
      </header>

      <section>
        <h2 style={styles.subheading}>Practices for Improving Emotional and Physical Well-Being</h2>
        <p style={styles.paragraph}>
          It’s a busy world. You fold the laundry while keeping one eye on the kids and another on the television. You plan your day while listening to the radio and commuting to work, and then plan your weekend. But in the rush to accomplish necessary tasks, you may find yourself losing your connection with the present moment—missing out on what you’re doing and how you’re feeling. Did you notice whether you felt well-rested this morning or that forsythia is in bloom along your route to work?
        </p>
        <p style={styles.paragraph}>
          Mindfulness is the practice of purposely focusing your attention on the present moment—and accepting it without judgment. Mindfulness is now being examined scientifically and has been found to be a key element in stress reduction and overall happiness.
        </p>
      </section>

      <section>
        <h2 style={styles.subheading}>What Are the Benefits of Mindfulness?</h2>
        <p style={styles.paragraph}>
          The cultivation of mindfulness has roots in Buddhism, but most religions include some type of prayer or meditation technique that helps shift your thoughts away from your usual preoccupations toward an appreciation of the moment and a larger perspective on life.
        </p>
        <p style={styles.paragraph}>
          Professor emeritus Jon Kabat-Zinn, founder and former director of the Stress Reduction Clinic at the University of Massachusetts Medical Center, helped to bring the practice of mindfulness meditation into mainstream medicine and demonstrated that practicing mindfulness can bring improvements in both physical and psychological symptoms as well as positive changes in health, attitudes, and behaviors.
        </p>
        <ul style={styles.list}>
          <li style={styles.listItem}><strong>Mindfulness improves well-being:</strong> Increasing your capacity for mindfulness supports many attitudes that contribute to a satisfied life. Being mindful makes it easier to savor the pleasures in life as they occur, helps you become fully engaged in activities, and creates a greater capacity to deal with adverse events.</li>
          <li style={styles.listItem}><strong>Mindfulness improves physical health:</strong> Scientists have discovered that mindfulness techniques help improve physical health in several ways, including stress relief, treating heart disease, lowering blood pressure, reducing chronic pain, improving sleep, and alleviating gastrointestinal difficulties.</li>
          <li style={styles.listItem}><strong>Mindfulness improves mental health:</strong> Mindfulness meditation is an important element in treating various problems, including depression, substance abuse, eating disorders, couples’ conflicts, anxiety disorders, and obsessive-compulsive disorder.</li>
        </ul>
      </section>

      <section>
        <h2 style={styles.subheading}>Mindfulness Techniques</h2>
        <p style={styles.paragraph}>
          There is more than one way to practice mindfulness, but the goal of any mindfulness technique is to achieve a state of alert, focused relaxation by deliberately paying attention to thoughts and sensations without judgment. This allows the mind to refocus on the present moment. All mindfulness techniques are a form of meditation.
        </p>
        <ul style={styles.list}>
          <li style={styles.listItem}><strong>Basic mindfulness meditation:</strong> Sit quietly and focus on your natural breathing or on a word or “mantra” that you repeat silently. Allow thoughts to come and go without judgment and return to your focus on breath or mantra.</li>
          <li style={styles.listItem}><strong>Body sensations:</strong> Notice subtle body sensations such as an itch or tingling without judgment and let them pass. Notice each part of your body in succession from head to toe.</li>
          <li style={styles.listItem}><strong>Sensory:</strong> Notice sights, sounds, smells, tastes, and touches. Name them “sight,” “sound,” “smell,” “taste,” or “touch” without judgment and let them go.</li>
          <li style={styles.listItem}><strong>Emotions:</strong> Allow emotions to be present without judgment. Practice a steady and relaxed naming of emotions: “joy,” “anger,” “frustration.” Accept the presence of the emotions without judgment and let them go.</li>
          <li style={styles.listItem}><strong>Urge surfing:</strong> Cope with cravings (for addictive substances or behaviors) and allow them to pass. Notice how your body feels as the craving enters. Replace the wish for the craving to go away with the certain knowledge that it will subside.</li>
        </ul>
      </section>

      <section>
        <h2 style={styles.subheading}>Mindfulness Meditation and Other Practices</h2>
        <p style={styles.paragraph}>
          Mindfulness can be cultivated through mindfulness meditation, a systematic method of focusing your attention. You can learn to meditate on your own, following instructions in books or on tape. However, you may benefit from the support of an instructor or group to answer questions and help you stay motivated. Look for someone using meditation in a way compatible with your beliefs and goals.
        </p>
        <p style={styles.paragraph}>
          If you have a medical condition, you may prefer a medically oriented program that incorporates meditation. Ask your physician or hospital about local groups. Insurance companies increasingly cover the cost of meditation instruction.
        </p>
      </section>

      <section>
        <h2 style={styles.subheading}>Mindfulness Exercises</h2>
        <h3 style={styles.subheading}>Basic Mindfulness Meditation</h3>
        <ol style={styles.list}>
          <li style={styles.listItem}>Sit on a straight-backed chair or cross-legged on the floor.</li>
          <li style={styles.listItem}>Focus on an aspect of your breathing, such as the sensations of air flowing into your nostrils and out of your mouth, or your belly rising and falling as you inhale and exhale.</li>
          <li style={styles.listItem}>Once you’ve narrowed your concentration in this way, begin to widen your focus. Become aware of sounds, sensations, and your ideas.</li>
          <li style={styles.listItem}>Embrace and consider each thought or sensation without judging it good or bad. If your mind starts to race, return your focus to your breathing. Then expand your awareness again.</li>
        </ol>

        <h3 style={styles.subheading}>Learning to Stay in the Present</h3>
        <p style={styles.paragraph}>
          A less formal approach to mindfulness can also help you to stay in the present and fully participate in your life. You can choose any task or moment to practice informal mindfulness, whether you are eating, showering, walking, touching a partner, or playing with a child or grandchild. Attending to these points will help:
        </p>
        <ul style={styles.list}>
          <li style={styles.listItem}>Start by bringing your attention to the sensations in your body</li>
          <li style={styles.listItem}>Breathe in through your nose, allowing the air downward into your lower belly. Let your abdomen expand fully.</li>
          <li style={styles.listItem}>Now breathe out through your mouth</li>
          <li style={styles.listItem}>Notice the sensations of each inhalation and exhalation</li>
          <li style={styles.listItem}>Proceed with the task at hand slowly and with full deliberation</li>
          <li style={styles.listItem}>Engage your senses and be present</li>
        </ul>
      </section>

      <footer style={styles.footer}>
        <p>© 2024 Mindfulness Inc. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default BenefitsOfMindfulness;
