
import React from 'react';
import Navbarr from './Navbarr';

const UnderstandingAnxiety = () => {
  const styles = {
    content: {
      padding: '2rem',
      backgroundColor: '#f9f9f9',
      fontFamily: 'Arial, sans-serif',
      color: '#333',
      maxWidth: '800px',
      margin: '0 auto',
      lineHeight: '1.6',
    },
    heading: {
      color: '#00796b',
    },
    illustration: {
      width: '100%',
      height: 'auto',
      margin: '1rem 0',
    },
    list: {
      listStyleType: 'none',
      padding: 0,
    },
    listItem: {
      backgroundColor: '#e0f7fa',
      margin: '0.5rem 0',
      padding: '0.5rem',
      borderRadius: '4px',
    },
    paragraph: {
      marginBottom: '1rem',
    },
  };

  return (
    <div style={styles.content}>
      <Navbarr/>
      <h1 style={styles.heading}>Understanding Anxiety Disorders</h1>
      <h2 style={styles.heading}>When Panic, Fear, and Worries Overwhelm</h2>
      <img
      src="https://newsinhealth.nih.gov/sites/newsinhealth/files/2016/March/illustration-worried-man-apart-circle-friends_0.jpg"
      style={styles.illustration}
      alt="Worried man apart from circle of friends"
    />


      <p style={styles.paragraph}>
        Many of us worry from time to time. We fret over finances, feel anxious about job interviews, or get nervous about social gatherings. These feelings can be normal or even helpful. They may give us a boost of energy or help us focus. But for people with anxiety disorders, they can be overwhelming.
      </p>

      <p style={styles.paragraph}>
        Anxiety disorders affect nearly 1 in 5 American adults each year. People with these disorders have feelings of fear and uncertainty that interfere with everyday activities and last for 6 months or more. Anxiety disorders can also raise your risk for other medical problems such as heart disease, diabetes, substance abuse, and depression.
      </p>

      <p style={styles.paragraph}>
        The good news is that most anxiety disorders get better with therapy. The course of treatment depends on the type of anxiety disorder. Medications, psychotherapy (“talk therapy”), or a combination of both can usually relieve troubling symptoms.
      </p>

      <p style={styles.paragraph}>
        “Anxiety disorders are one of the most treatable mental health problems we see,” says Dr. Daniel Pine, an NIH neuroscientist and psychiatrist. “Still, for reasons we don’t fully understand, most people who have these problems don’t get the treatments that could really help them.”
      </p>

      <p style={styles.paragraph}>
        One of the most common types of anxiety disorder is social anxiety disorder, or social phobia. It affects both women and men equally—a total of about 15 million U.S. adults. Without treatment, social phobia can last for years or even a lifetime. People with social phobia may worry for days or weeks before a social event. They’re often embarrassed, self-conscious, and afraid of being judged. They find it hard to talk to others. They may blush, sweat, tremble, or feel sick to their stomach when around other people.
      </p>

      <p style={styles.paragraph}>
        Other common types of anxiety disorders include generalized anxiety disorder, which affects nearly 7 million American adults, and panic disorder, which affects about 6 million. Both are twice as common in women as in men.
      </p>

      <p style={styles.paragraph}>
        People with generalized anxiety disorder worry endlessly over everyday issues—like health, money, or family problems—even if they realize there’s little cause for concern. They startle easily, can’t relax, and can’t concentrate. They find it hard to fall asleep or stay asleep. They may get headaches, muscle aches, or unexplained pains. Symptoms often get worse during times of stress.
      </p>

      <p style={styles.paragraph}>
        People with panic disorder have sudden, repeated bouts of fear—called panic attacks—that last several minutes or more. During a panic attack, they may feel that they can’t breathe or that they’re having a heart attack. They may fear loss of control or feel a sense of unreality. Not everyone who has panic attacks will develop panic disorder. But if the attacks recur without warning, creating fear of having another attack at any time, then it’s likely panic disorder.
      </p>

      <p style={styles.paragraph}>
        Anxiety disorders tend to run in families. But researchers aren’t certain why some family members develop these conditions while others don’t. No specific genes have been found to actually cause an anxiety disorder. “Many different factors—including genes, stress, and the environment—have small effects that add up in complex ways to affect a person’s risk for these disorders,” Pine says.
      </p>

      <p style={styles.paragraph}>
        “Many kids with anxiety disorders will outgrow their conditions. But most anxiety problems we see in adults started during their childhood,” Pine adds.
      </p>

      <p style={styles.paragraph}>
        “Anxiety disorders are among the most common psychiatric disorders in children, with an estimated 1 in 3 suffering anxiety at some point during childhood or adolescence,” says Dr. Susan Whitfield-Gabrieli, a brain imaging expert at the Massachusetts Institute of Technology. “About half of diagnosable mental health disorders start by age 14, so there’s a lot of interest in uncovering the factors that might influence the brain by those early teen years.”
      </p>

      <p style={styles.paragraph}>
        Whitfield-Gabrieli is launching an NIH-funded study to create detailed MRI images of the brains of more than 200 teens, ages 14-15, with and without anxiety or depression. The scientists will then assess what brain structures and activities might be linked to these conditions. The study is part of NIH’s Human Connectome Project, in which research teams across the country are studying the complex brain connections that affect health and disease.
      </p>

      <p style={styles.paragraph}>
        Whitfield-Gabrieli and colleagues have shown that analysis of brain connections might help predict which adults with social phobia will likely respond to cognitive behavioral therapy (CBT). CBT is a type of talk therapy known to be effective for people with anxiety disorders. It helps them change their thinking patterns and how they react to anxiety-provoking situations. But it doesn’t work for everyone.
      </p>

      <p style={styles.paragraph}>
        Of 38 adults with social phobia, those who responded best after 3 months of CBT had similar patterns of brain connections. This brain analysis led to major improvement, compared to a clinician’s assessment alone, in predicting treatment response. Larger studies will be needed to confirm the benefits of the approach.
      </p>

      <p style={styles.paragraph}>
        “Ultimately, we hope that brain imaging will help us predict clinical outcomes and actually tailor the treatment to each individual—to know whether they’ll respond best to psychotherapy or to certain medications,” Whitfield-Gabrieli says.
      </p>

      <p style={styles.paragraph}>
        Other researchers are focusing on our emotions and our ability to adjust them. “We want to understand not only how emotions can help us but also how they can create difficulties if they’re of the wrong intensity or the wrong type for a particular situation,” says Dr. James Gross, a clinical psychologist at Stanford University.
      </p>

      <p style={styles.paragraph}>
        We all use different strategies to adjust our emotions, often without thinking about it. If something makes you angry, you may try to tamp down your emotion to avoid making a scene. If something annoys you, you might try to ignore it, modify it, or entirely avoid it.
      </p>

      <p style={styles.paragraph}>
        But these strategies can turn harmful over time. For instance, people with social phobia might decide to avoid attending a professional conference so they can keep their anxiety in check. That makes them lose opportunities at work and miss chances to meet people and make friends.
      </p>

      <p style={styles.paragraph}>
        Gross and others are examining the differences between how people with and without anxiety disorders regulate their emotions. “We’re finding that CBT is helpful in part because it teaches people to more effectively use emotion regulation strategies,” Gross says. “They then become more competent in their ability to use these strategies in their everyday lives.”
      </p>

      <p style={styles.paragraph}>
        “It’s important to be aware that many different kinds of treatments are available, and people with anxiety disorders tend to have very good responses to those treatments,” Pine adds. The best way to start is often by talking with your physician. If you’re a parent, talk with your child’s pediatrician. “These health professionals are generally prepared to help identify such problems and help patients get the appropriate care they need,” Pine says.
      </p> 

      
    </div>
  );
};

export default UnderstandingAnxiety;

