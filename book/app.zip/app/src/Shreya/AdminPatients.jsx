import React, { useState } from 'react';

import Navbar from './Navbar';

const AdminPatients = () => {
  // Sample data for patients
  const initialPatients = [
    { id: '001', name: 'John Doe', age: 30, problem: 'Anxiety', date: '2024-07-15' },
    { id: '002', name: 'Jane Smith', age: 25, problem: 'Depression', date: '2024-07-20' },
    { id: '003', name: 'Michael Johnson', age: 45, problem: 'Stress', date: '2024-08-01' },
    { id: '004', name: 'Emily Davis', age: 32, problem: 'Bipolar Disorder', date: '2024-08-05' },
    { id: '005', name: 'Chris Brown', age: 29, problem: 'PTSD', date: '2024-07-28' },
    { id: '006', name: 'Jessica Wilson', age: 40, problem: 'OCD', date: '2024-08-02' },
    { id: '007', name: 'David Lee', age: 37, problem: 'Eating Disorder', date: '2024-08-10' },
    { id: '008', name: 'Laura Martinez', age: 28, problem: 'Schizophrenia', date: '2024-08-07' },
    { id: '009', name: 'Daniel Garcia', age: 35, problem: 'Addiction', date: '2024-07-22' },
    { id: '010', name: 'Sophia Brown', age: 31, problem: 'Personality Disorder', date: '2024-08-03' },
    
  ];

  const [searchQuery, setSearchQuery] = useState('');
  const [patients, setPatients] = useState(initialPatients);

  const handleSearch = (event) => {
    const query = event.target.value.toLowerCase();
    setSearchQuery(query);

    // Filter patients based on the search query
    const filteredPatients = initialPatients.filter(patient =>
      patient.name.toLowerCase().includes(query) ||
      patient.id.toLowerCase().includes(query) ||
      patient.problem.toLowerCase().includes(query)
    );

    setPatients(filteredPatients);
  };

  return (
    <div className="patients-container">
      <Navbar/>
      
      <header className="header">
        <h1>Patients</h1>
        <p>Manage patient records and information here.</p>
      </header>
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search patients by name, ID, or problem..."
          value={searchQuery}
          onChange={handleSearch}
          className="search-input"
        />
      </div>
      <div className="patients-content">
        <table className="patients-table">
          <thead>
            <tr>
              <th>Patient ID</th>
              <th>Name</th>
              <th>Age</th>
              <th>Problem</th>
              <th>Date of Registration</th>
            </tr>
          </thead>
          <tbody>
            {patients.length > 0 ? (
              patients.map((patient) => (
                <tr key={patient.id}>
                  <td>{patient.id}</td>
                  <td>{patient.name}</td>
                  <td>{patient.age}</td>
                  <td>{patient.problem}</td>
                  <td>{patient.date}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5">No patients found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <style jsx>{`
        .patients-container {
          padding: 20px;
          text-align: center;
        }
        .header {
          margin-bottom: 20px;
        }
        h1 {
          color: #007bff;
          margin-bottom: 10px;
        }
        
        .search-bar {
          margin-bottom: 20px;
        }
        .search-input {
          width: 100%;
          max-width: 600px;
          padding: 10px;
          border: 1px solid #ced4da;
          border-radius: 5px;
          font-size: 16px;
          transition: border-color 0.3s ease;
        }
        .search-input:focus {
          border-color: #007bff;
          outline: none;
        }
        .patients-content {
          text-align: left;
          max-width: 1000px;
          margin: 0 auto;
        }
        .patients-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
        }
        .patients-table th, .patients-table td {
          padding: 12px;
          border: 1px solid #dee2e6;
          text-align: center;
        }
        .patients-table th {
          background-color: #f8f9fa;
          color: #0056b3;
        }
        .patients-table tr:nth-child(even) {
          background-color: #f2f2f2;
        }
        .patients-table tr:hover {
          background-color: #e9ecef;
          transition: background-color 0.3s ease;
        }
      `}</style>
    </div>
  );
};

export default AdminPatients;
